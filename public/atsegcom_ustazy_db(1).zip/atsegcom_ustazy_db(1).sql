-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 13, 2026 at 05:47 AM
-- Server version: 5.7.23-23
-- PHP Version: 8.1.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atsegcom_ustazy_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `answer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `answer`, `is_correct`, `created_at`, `updated_at`) VALUES
(23, 10, 'صح', 0, '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(22, 9, 'صح', 0, '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(21, 9, 'خطأ', 1, '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(4, 2, 'خطأ', 1, '2026-01-13 10:34:45', '2026-01-13 10:34:45'),
(5, 2, 'صح', 0, '2026-01-13 10:34:45', '2026-01-13 10:34:45'),
(6, 3, 'الولدُ', 1, '2026-01-13 10:52:19', '2026-01-13 10:52:19'),
(7, 3, 'اللبنَ', 0, '2026-01-13 10:52:19', '2026-01-13 10:52:19'),
(8, 3, 'شربَ', 0, '2026-01-13 10:52:19', '2026-01-13 10:52:19'),
(9, 4, 'خطأ', 1, '2026-01-13 10:52:19', '2026-01-13 10:52:19'),
(10, 4, 'صح', 0, '2026-01-13 10:52:19', '2026-01-13 10:52:19'),
(11, 5, 'الولدُ', 1, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(12, 5, 'اللبنَ', 0, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(13, 5, 'شربَ', 0, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(14, 6, 'خطأ', 1, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(15, 6, 'صح', 0, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(16, 7, 'صح', 0, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(17, 7, 'خطأ', 1, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(18, 8, 'فى محل رفع ', 1, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(19, 8, 'فى محل نصب ', 0, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(20, 8, 'فى محل جر', 0, '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(24, 10, 'خطأ', 1, '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(25, 11, 'فى محل رفع ', 1, '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(26, 11, 'فى محل نصب ', 0, '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(27, 11, 'فى محل جر', 0, '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(33, 12, 'اللبنَ', 0, '2026-01-14 07:20:56', '2026-01-14 07:20:56'),
(32, 12, 'الولدُ', 1, '2026-01-14 07:20:56', '2026-01-14 07:20:56'),
(31, 12, 'شربَ', 0, '2026-01-14 07:20:56', '2026-01-14 07:20:56'),
(34, 13, 'صواب', 0, '2026-01-14 09:08:09', '2026-01-14 09:08:09'),
(35, 13, 'خطأ', 1, '2026-01-14 09:08:09', '2026-01-14 09:08:09'),
(36, 14, 'صواب', 1, '2026-01-14 09:08:40', '2026-01-14 09:08:40'),
(37, 14, 'خطأ', 0, '2026-01-14 09:08:40', '2026-01-14 09:08:40'),
(38, 15, 'a) will pass', 1, '2026-01-14 09:50:48', '2026-01-14 09:50:48'),
(39, 15, 'b) would pass', 0, '2026-01-14 09:50:48', '2026-01-14 09:50:48'),
(40, 15, 'c) would have passed', 0, '2026-01-14 09:50:48', '2026-01-14 09:50:48'),
(41, 15, 'd) pass', 0, '2026-01-14 09:50:48', '2026-01-14 09:50:48'),
(42, 16, '2', 1, '2026-02-25 20:15:36', '2026-02-25 20:15:36'),
(43, 16, '3', 0, '2026-02-25 20:15:36', '2026-02-25 20:15:36'),
(44, 17, 'Apple1', 1, '2026-03-02 19:26:47', '2026-03-02 19:26:47'),
(45, 17, 'Apple2', 0, '2026-03-02 19:26:47', '2026-03-02 19:26:47'),
(46, 17, 'Apple3', 0, '2026-03-02 19:26:47', '2026-03-02 19:26:47'),
(47, 18, 'Fine1', 1, '2026-03-02 19:26:47', '2026-03-02 19:26:47'),
(48, 18, 'Fine2', 0, '2026-03-02 19:26:47', '2026-03-02 19:26:47'),
(49, 18, 'Fine3', 0, '2026-03-02 19:26:47', '2026-03-02 19:26:47');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `section_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `attachment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_date` timestamp NULL DEFAULT NULL,
  `max_score` int(11) NOT NULL DEFAULT '100',
  `allow_late_submission` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assignment_submissions`
--

CREATE TABLE `assignment_submissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `assignment_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `file_path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `score` int(11) DEFAULT NULL,
  `feedback` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','graded','late') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `submitted_at` timestamp NULL DEFAULT NULL,
  `graded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('spatie.permission.cache', 'a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:42:{i:0;a:4:{s:1:\"a\";i:61;s:1:\"b\";s:20:\"view_student_courses\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:1;a:4:{s:1:\"a\";i:60;s:1:\"b\";s:15:\"enroll_students\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:2;}}i:2;a:4:{s:1:\"a\";i:59;s:1:\"b\";s:14:\"delete subject\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:3;a:4:{s:1:\"a\";i:58;s:1:\"b\";s:12:\"edit subject\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:4;a:4:{s:1:\"a\";i:57;s:1:\"b\";s:14:\"create subject\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:5;a:4:{s:1:\"a\";i:56;s:1:\"b\";s:15:\"manage_subjects\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:6;a:4:{s:1:\"a\";i:55;s:1:\"b\";s:12:\"delete grade\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:7;a:4:{s:1:\"a\";i:54;s:1:\"b\";s:10:\"edit grade\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:8;a:4:{s:1:\"a\";i:53;s:1:\"b\";s:12:\"create grade\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:9;a:4:{s:1:\"a\";i:52;s:1:\"b\";s:13:\"manage_grades\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:10;a:4:{s:1:\"a\";i:51;s:1:\"b\";s:22:\"delete_education_level\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:11;a:4:{s:1:\"a\";i:50;s:1:\"b\";s:20:\"edit_education_level\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:12;a:4:{s:1:\"a\";i:49;s:1:\"b\";s:22:\"create_education_level\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:13;a:4:{s:1:\"a\";i:48;s:1:\"b\";s:23:\"manage_education_levels\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:14;a:4:{s:1:\"a\";i:47;s:1:\"b\";s:24:\"access_student_dashboard\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:3;i:2;i:5;}}i:15;a:4:{s:1:\"a\";i:46;s:1:\"b\";s:24:\"access_teacher_dashboard\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:16;a:4:{s:1:\"a\";i:45;s:1:\"b\";s:22:\"access_admin_dashboard\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:17;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:9:\"view user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:18;a:4:{s:1:\"a\";i:26;s:1:\"b\";s:11:\"create user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:19;a:4:{s:1:\"a\";i:27;s:1:\"b\";s:9:\"edit user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:20;a:4:{s:1:\"a\";i:28;s:1:\"b\";s:11:\"delete user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:21;a:4:{s:1:\"a\";i:29;s:1:\"b\";s:9:\"view role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:22;a:4:{s:1:\"a\";i:30;s:1:\"b\";s:11:\"create role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:23;a:4:{s:1:\"a\";i:31;s:1:\"b\";s:9:\"edit role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:24;a:4:{s:1:\"a\";i:32;s:1:\"b\";s:11:\"delete role\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}i:25;a:4:{s:1:\"a\";i:33;s:1:\"b\";s:11:\"view course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:26;a:4:{s:1:\"a\";i:34;s:1:\"b\";s:13:\"create course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:27;a:4:{s:1:\"a\";i:35;s:1:\"b\";s:11:\"edit course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:28;a:4:{s:1:\"a\";i:36;s:1:\"b\";s:13:\"delete course\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:29;a:4:{s:1:\"a\";i:37;s:1:\"b\";s:11:\"view lesson\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:4;}}i:30;a:4:{s:1:\"a\";i:38;s:1:\"b\";s:13:\"create lesson\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:31;a:4:{s:1:\"a\";i:39;s:1:\"b\";s:11:\"edit lesson\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:32;a:4:{s:1:\"a\";i:40;s:1:\"b\";s:13:\"delete lesson\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:33;a:4:{s:1:\"a\";i:41;s:1:\"b\";s:9:\"view quiz\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:34;a:4:{s:1:\"a\";i:42;s:1:\"b\";s:11:\"create quiz\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:35;a:4:{s:1:\"a\";i:43;s:1:\"b\";s:9:\"edit quiz\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:36;a:4:{s:1:\"a\";i:44;s:1:\"b\";s:11:\"delete quiz\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:1;i:1;i:2;i:2;i:4;}}i:37;a:4:{s:1:\"a\";i:62;s:1:\"b\";s:21:\"view_student_wishlist\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:38;a:4:{s:1:\"a\";i:63;s:1:\"b\";s:20:\"view_student_reviews\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:39;a:4:{s:1:\"a\";i:64;s:1:\"b\";s:21:\"view_student_attempts\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:40;a:4:{s:1:\"a\";i:65;s:1:\"b\";s:19:\"view_student_orders\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:1;i:1;i:3;}}i:41;a:4:{s:1:\"a\";i:66;s:1:\"b\";s:24:\"manage_roles_permissions\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:1;}}}s:5:\"roles\";a:5:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:5:\"admin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:3;s:1:\"b\";s:7:\"student\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:7:\"teacher\";s:1:\"c\";s:3:\"web\";}i:3;a:3:{s:1:\"a\";i:5;s:1:\"b\";s:6:\"parent\";s:1:\"c\";s:3:\"web\";}i:4;a:3:{s:1:\"a\";i:4;s:1:\"b\";s:17:\"assistant_teacher\";s:1:\"c\";s:3:\"web\";}}}', 1776090580);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `expires_at` date DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `used_count` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `requirements` text COLLATE utf8mb4_unicode_ci,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_source` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `enrollment_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `title`, `description`, `requirements`, `level`, `price`, `image`, `video_source`, `video_url`, `teacher_id`, `subject_id`, `status`, `enrollment_code`, `created_at`, `updated_at`) VALUES
(11, 'اللغة العربية - الترم الاول - الصف الأول الثانوي', 'اللغة العربية - الترم الاول - الصف الأول الثانوي', NULL, NULL, 200.00, 'courses/NhQDMRaZBnefo25aBJ3rQCOTw2u8K98tNAmPl2LW.png', 'youtube', NULL, 4, 2, 'published', NULL, '2026-02-14 16:48:19', '2026-03-17 18:20:33');

-- --------------------------------------------------------

--
-- Table structure for table `course_student`
--

CREATE TABLE `course_student` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `progress` int(11) NOT NULL DEFAULT '0',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `enrolled_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course_student`
--

INSERT INTO `course_student` (`id`, `course_id`, `student_id`, `progress`, `status`, `enrolled_at`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 6, 1, 0, 'active', NULL, NULL, '2026-01-12 13:02:25', '2026-01-12 13:02:25'),
(2, 8, 9, 0, 'active', NULL, NULL, '2026-01-13 10:27:12', '2026-01-13 10:27:12'),
(3, 8, 1, 0, 'active', NULL, NULL, '2026-01-13 10:27:24', '2026-01-13 10:27:24'),
(4, 9, 1, 0, 'active', NULL, NULL, '2026-01-13 10:34:45', '2026-01-13 10:34:45'),
(10, 11, 13, 0, 'active', NULL, NULL, '2026-03-17 18:33:45', '2026-03-17 18:35:46'),
(11, 11, 14, 0, 'active', NULL, NULL, '2026-03-17 18:39:47', '2026-03-17 18:40:28');

-- --------------------------------------------------------

--
-- Table structure for table `education_levels`
--

CREATE TABLE `education_levels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `education_levels`
--

INSERT INTO `education_levels` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'ثانوية عامة', '2025-12-16 07:29:26', '2025-12-16 07:29:26');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `education_level_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `education_level_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 'الصف الاول الثانوي', '2025-12-16 07:29:40', '2026-01-13 07:56:42'),
(2, 1, 'الصف الثاني الثانوي', '2026-01-13 07:56:31', '2026-01-13 07:56:31'),
(3, 1, 'الصف الثالث الثانوي', '2026-01-19 21:26:29', '2026-01-19 21:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--

CREATE TABLE `lessons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `section_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_source` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pdf` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audio` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `is_preview` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `section_id`, `position`, `title`, `video`, `video_source`, `video_url`, `pdf`, `audio`, `duration`, `content`, `is_preview`, `created_at`, `updated_at`) VALUES
(27, 22, 0, 'انواع الكلمة', '', 'upload', '', 'temp_uploads/I58CZ4N4ZQ7mNI9hEhRCUKSEA53Zc16GFpVamIsr.pdf', NULL, '', '', 0, '2026-03-17 18:39:02', '2026-03-17 18:39:02'),
(28, 22, 0, 'الفصل الاول -مقدمة', NULL, 'external', 'https://www.youtube.com/watch?v=1gWVCoYAcVs', '', NULL, '', '', 0, '2026-03-17 18:39:02', '2026-03-17 18:39:02'),
(29, 22, 0, 'الدرس الثالث: شرح الهمزة', NULL, 'external', 'https://drive.google.com/file/d/19lxJme9W2SC8naEjUBiLbNeSN9cl67sd/view?usp=sharing', '', NULL, '', 'شرح سريع عن الهمزة المتوسطة وغيرها من الحركات', 0, '2026-03-17 18:39:02', '2026-03-17 18:39:02');

-- --------------------------------------------------------

--
-- Table structure for table `lesson_files`
--

CREATE TABLE `lesson_files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lesson_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('video','pdf','audio') COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lesson_student`
--

CREATE TABLE `lesson_student` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lesson_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `progress` int(11) NOT NULL DEFAULT '0',
  `last_accessed_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_activities`
--

CREATE TABLE `login_activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_activities`
--

INSERT INTO `login_activities` (`id`, `user_id`, `ip_address`, `user_agent`, `created_at`, `updated_at`) VALUES
(1, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-14 12:25:15', '2026-01-14 12:25:15'),
(2, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-14 12:25:15', '2026-01-14 12:25:15'),
(3, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-15 10:45:15', '2026-01-15 10:45:15'),
(4, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', '2026-01-15 10:45:16', '2026-01-15 10:45:16'),
(5, 13, '197.52.173.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-03-01 19:57:02', '2026-03-01 19:57:02'),
(6, 13, '197.52.173.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-03-01 19:57:02', '2026-03-01 19:57:02'),
(7, 13, '197.52.173.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-03-01 19:58:27', '2026-03-01 19:58:27'),
(8, 13, '197.52.173.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-03-01 19:58:27', '2026-03-01 19:58:27'),
(9, 13, '197.52.173.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-03-01 20:12:43', '2026-03-01 20:12:43'),
(10, 13, '197.52.173.136', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0', '2026-03-01 20:12:43', '2026-03-01 20:12:43'),
(11, 13, '41.233.220.58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-02 19:22:05', '2026-03-02 19:22:05'),
(12, 13, '41.233.220.58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-02 19:22:06', '2026-03-02 19:22:06'),
(13, 13, '41.233.220.58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-02 19:27:29', '2026-03-02 19:27:29'),
(14, 13, '41.233.220.58', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-02 19:27:29', '2026-03-02 19:27:29'),
(15, 13, '41.44.126.188', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-08 15:29:00', '2026-03-08 15:29:00'),
(16, 13, '41.44.126.188', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-08 15:29:00', '2026-03-08 15:29:00'),
(17, 13, '41.44.126.188', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-09 15:36:39', '2026-03-09 15:36:39'),
(18, 13, '41.44.126.188', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-09 15:36:39', '2026-03-09 15:36:39'),
(19, 13, '41.44.126.188', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-10 13:09:03', '2026-03-10 13:09:03'),
(20, 13, '41.44.126.188', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-10 13:09:03', '2026-03-10 13:09:03'),
(21, 14, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-16 19:23:56', '2026-03-16 19:23:56'),
(22, 14, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-16 19:23:56', '2026-03-16 19:23:56'),
(23, 14, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-17 13:41:35', '2026-03-17 13:41:35'),
(24, 14, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-17 13:41:35', '2026-03-17 13:41:35'),
(25, 14, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-17 14:56:23', '2026-03-17 14:56:23'),
(26, 14, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-17 14:56:23', '2026-03-17 14:56:23'),
(27, 13, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-17 18:33:10', '2026-03-17 18:33:10'),
(28, 13, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-17 18:33:10', '2026-03-17 18:33:10'),
(29, 13, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-17 18:35:56', '2026-03-17 18:35:56'),
(30, 13, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-17 18:35:56', '2026-03-17 18:35:56'),
(31, 13, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-17 18:39:37', '2026-03-17 18:39:37'),
(32, 13, '156.213.169.108', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:148.0) Gecko/20100101 Firefox/148.0', '2026-03-17 18:39:37', '2026-03-17 18:39:37'),
(33, 16, '197.52.90.65', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-04-12 20:29:40', '2026-04-12 20:29:40'),
(34, 16, '197.52.90.65', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-04-12 20:29:40', '2026-04-12 20:29:40');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_11_23_080333_create_permission_tables', 1),
(5, '2025_11_24_132627_create_education_levels_table', 1),
(6, '2025_11_24_132743_create_grades_table', 1),
(7, '2025_11_24_132835_create_subjects_table', 1),
(8, '2025_11_24_133852_create_students_table', 1),
(9, '2025_11_24_133947_create_parent_student_table', 1),
(10, '2025_11_24_134800_create_teacher_education_level_table', 1),
(11, '2025_11_24_134806_create_teacher_subject_table', 1),
(12, '2025_12_03_114510_add_phone_to_users_table', 1),
(13, '2025_12_03_115201_add_phone_to_students_table', 1),
(14, '2025_12_03_151817_add_profile_image_to_users_table', 1),
(15, '2025_12_04_113200_create_student_subject_table', 1),
(16, '2025_12_07_121446_create_courses_table', 1),
(17, '2025_12_07_144637_create_questions_table', 1),
(18, '2025_12_07_144728_create_answers_table', 1),
(19, '2025_12_08_111547_create_course_student_table', 1),
(20, '2025_12_08_111551_create_lesson_student_table', 1),
(21, '2025_12_08_111556_create_quiz_student_table', 1),
(22, '2025_12_08_140447_add_subject_id_to_courses_table', 1),
(23, '2025_12_15_083344_create_sections_table', 1),
(24, '2025_12_15_143226_create_lessons_table', 1),
(25, '2025_12_15_144551_create_quizzes_table', 1),
(26, '2025_12_15_183555_create_assignments_table', 1),
(27, '2025_12_16_154956_add_media_columns_to_lessons_table', 2),
(28, '2025_12_17_152604_create_lesson_files_table', 3),
(29, '2025_12_22_075454_add_type_to_quizzes_table', 4),
(30, '2026_01_08_112749_add_teacher_id_to_users_table', 5),
(31, '2026_01_08_154823_add_description_to_courses_table', 6),
(32, '2026_01_10_175215_add_lesson_id_to_quizzes_table', 6),
(33, '2026_01_11_113459_create_coupons_table', 7),
(34, '2026_01_11_113500_create_order_items_table', 7),
(35, '2026_01_11_113500_create_orders_table', 7),
(36, '2026_01_11_115206_add_requirements_and_level_to_courses_table', 8),
(37, '2026_01_11_115256_create_settings_table', 9),
(38, '2026_01_11_115328_add_position_and_preview_to_lessons_table', 9),
(39, '2026_01_11_115328_add_position_to_sections_table', 9),
(40, '2026_01_11_120712_create_notifications_table', 10),
(41, '2026_01_11_122320_add_progress_fields_to_lesson_student_table', 11),
(42, '2026_01_11_122349_add_progress_to_course_student_table', 11),
(43, '2026_01_11_122424_enhance_assignments_table', 11),
(44, '2026_01_11_122425_create_assignment_submissions_table', 11),
(45, '2026_01_12_135955_fix_course_student_columns', 12),
(46, '2026_01_12_160000_fix_progress_columns_names', 12),
(47, '2026_01_13_142503_update_questions_type_column', 13),
(48, '2026_01_13_144323_add_user_answers_to_quiz_student_table', 14),
(49, '2026_01_13_164500_add_user_answers_to_quiz_student_table', 14),
(50, '2026_01_13_150738_add_attempts_limit_to_quizzes_table', 15),
(51, '2026_01_13_170800_add_attempts_limit_to_quizzes_table', 15),
(52, '2026_01_13_171200_add_attempt_count_to_quiz_student_table', 16),
(53, '2026_01_14_093119_modify_quizzes_table_for_general_exams', 17),
(54, '2026_01_14_110513_add_time_limit_to_quizzes_table', 18),
(55, '2026_01_14_124923_create_login_activities_table', 19),
(56, '2026_04_06_000001_add_parent_phone_and_academic_year_to_students_table', 20);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 5),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3),
(2, 'App\\Models\\User', 4),
(2, 'App\\Models\\User', 12),
(3, 'App\\Models\\User', 13),
(3, 'App\\Models\\User', 14),
(3, 'App\\Models\\User', 15),
(3, 'App\\Models\\User', 16);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `parent_student`
--

CREATE TABLE `parent_student` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `parent_student`
--

INSERT INTO `parent_student` (`id`, `parent_id`, `student_id`, `created_at`, `updated_at`) VALUES
(2, 8, 1, '2026-01-13 09:04:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(225) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(61, 'view_student_courses', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(60, 'enroll_students', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(59, 'delete subject', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(58, 'edit subject', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(57, 'create subject', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(56, 'manage_subjects', 'web', '2026-01-15 12:34:06', '2026-01-15 12:58:40'),
(55, 'delete grade', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(54, 'edit grade', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(53, 'create grade', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(52, 'manage_grades', 'web', '2026-01-15 12:34:06', '2026-01-15 12:58:00'),
(51, 'delete_education_level', 'web', '2026-01-15 12:34:06', '2026-01-15 12:54:25'),
(50, 'edit_education_level', 'web', '2026-01-15 12:34:06', '2026-01-15 12:54:35'),
(49, 'create_education_level', 'web', '2026-01-15 12:34:06', '2026-01-15 12:54:44'),
(48, 'manage_education_levels', 'web', '2026-01-15 12:34:06', '2026-01-15 12:57:30'),
(47, 'access_student_dashboard', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(46, 'access_teacher_dashboard', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(45, 'access_admin_dashboard', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(25, 'view user', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(26, 'create user', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(27, 'edit user', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(28, 'delete user', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(29, 'view role', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(30, 'create role', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(31, 'edit role', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(32, 'delete role', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(33, 'view course', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(34, 'create course', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(35, 'edit course', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(36, 'delete course', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(37, 'view lesson', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(38, 'create lesson', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15'),
(39, 'edit lesson', 'web', '2026-01-15 12:22:16', '2026-01-15 12:22:16'),
(40, 'delete lesson', 'web', '2026-01-15 12:22:16', '2026-01-15 12:22:16'),
(41, 'view quiz', 'web', '2026-01-15 12:22:16', '2026-01-15 12:22:16'),
(42, 'create quiz', 'web', '2026-01-15 12:22:16', '2026-01-15 12:22:16'),
(43, 'edit quiz', 'web', '2026-01-15 12:22:16', '2026-01-15 12:22:16'),
(44, 'delete quiz', 'web', '2026-01-15 12:22:16', '2026-01-15 12:22:16'),
(62, 'view_student_wishlist', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(63, 'view_student_reviews', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(64, 'view_student_attempts', 'web', '2026-01-15 12:34:06', '2026-01-15 12:34:06'),
(65, 'view_student_orders', 'web', '2026-01-15 12:34:07', '2026-01-15 12:34:07'),
(66, 'manage_roles_permissions', 'web', '2026-01-15 12:22:15', '2026-01-15 12:22:15');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quiz_id` bigint(20) UNSIGNED NOT NULL,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'mcq',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `quiz_id`, `question`, `type`, `created_at`, `updated_at`) VALUES
(1, 4, 'ما هو الفاعل في جملة \"شربَ الولدُ اللبنَ\"؟', 'multiple_choice', '2026-01-13 10:34:44', '2026-01-13 10:34:44'),
(2, 4, 'الفعل المضارع دائماً ما يكون مبنياً.', 'true_false', '2026-01-13 10:34:45', '2026-01-13 10:34:45'),
(3, 5, 'ما هو الفاعل في جملة \"شربَ الولدُ اللبنَ\"؟', 'multiple_choice', '2026-01-13 10:52:19', '2026-01-13 10:52:19'),
(4, 5, 'الفعل المضارع دائماً ما يكون مبنياً.', 'true_false', '2026-01-13 10:52:19', '2026-01-13 10:52:19'),
(5, 6, 'ما هو الفاعل في جملة \"شربَ الولدُ اللبنَ\"؟', 'multiple_choice', '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(6, 6, 'الفعل المضارع دائماً ما يكون مبنياً.', 'true_false', '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(7, 6, 'الفاعل دائما منصوب', 'true_false', '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(8, 6, 'اعراف اسم الفاعل ', 'multiple_choice', '2026-01-13 11:08:03', '2026-01-13 11:08:03'),
(9, 7, 'الفعل المضارع دائماً ما يكون مبنياً.', 'true_false', '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(10, 7, 'الفاعل دائما منصوب', 'true_false', '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(11, 7, 'اعراف اسم الفاعل ', 'multiple_choice', '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(12, 7, 'ما هو الفاعل في جملة \"شربَ الولدُ اللبنَ\"؟', 'multiple_choice', '2026-01-13 11:11:59', '2026-01-13 11:11:59'),
(13, 8, 'اعراف الفعل المضارع ديما منصوب', 'true_false', '2026-01-14 09:08:09', '2026-01-14 09:08:09'),
(14, 8, 'اعراف الفاعل ديما مرفوع', 'true_false', '2026-01-14 09:08:40', '2026-01-14 09:08:40'),
(15, 9, 'If I had studied harder, I _____ the exam.', 'multiple_choice', '2026-01-14 09:50:48', '2026-01-14 09:50:48'),
(16, 10, '1 + 1', 'multiple_choice', '2026-02-25 20:15:36', '2026-02-25 20:15:36'),
(17, 11, 'What is an apple?', 'multiple_choice', '2026-03-02 19:26:47', '2026-03-02 19:26:47'),
(18, 11, 'How are you?', 'multiple_choice', '2026-03-02 19:26:47', '2026-03-02 19:26:47');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

CREATE TABLE `quizzes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `section_id` bigint(20) UNSIGNED DEFAULT NULL,
  `lesson_id` bigint(20) UNSIGNED DEFAULT NULL,
  `time_limit` int(11) DEFAULT NULL,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('daily','monthly','normal') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `attempts_limit` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `section_id`, `lesson_id`, `time_limit`, `teacher_id`, `title`, `type`, `attempts_limit`, `created_at`, `updated_at`) VALUES
(8, NULL, NULL, 60, 4, 'اختبار تحديد مستوي - لغة عربية', 'normal', 2, '2026-01-14 09:07:20', '2026-01-14 09:07:20');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_student`
--

CREATE TABLE `quiz_student` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `quiz_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `score` int(11) DEFAULT NULL,
  `user_answers` json DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  `attempt_count` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_student`
--

INSERT INTO `quiz_student` (`id`, `quiz_id`, `student_id`, `score`, `user_answers`, `completed`, `attempt_count`, `created_at`, `updated_at`) VALUES
(3, 7, 1, 100, '{\"9\": \"21\", \"10\": \"24\", \"11\": \"25\", \"12\": \"32\"}', 1, 3, '2026-01-14 09:28:45', '2026-01-14 12:58:34'),
(4, 9, 1, 100, '{\"15\": \"38\"}', 1, 2, '2026-01-14 12:31:45', '2026-01-14 12:36:11'),
(13, 11, 13, 100, '{\"17\": \"44\", \"18\": \"47\"}', 1, 1, '2026-03-02 19:27:59', '2026-03-02 19:27:59');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(225) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'web', '2025-12-16 07:22:00', '2025-12-16 07:22:00'),
(2, 'teacher', 'web', '2025-12-16 07:27:48', '2025-12-16 07:27:48'),
(3, 'student', 'web', '2025-12-16 07:28:01', '2025-12-16 07:28:01'),
(4, 'assistant_teacher', 'web', '2026-01-08 09:34:45', '2026-01-08 09:34:45'),
(5, 'parent', 'web', '2026-01-10 15:43:13', '2026-01-10 15:43:13');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(33, 2),
(33, 4),
(34, 1),
(34, 2),
(34, 4),
(35, 1),
(35, 2),
(35, 4),
(36, 1),
(36, 2),
(36, 4),
(37, 4),
(38, 1),
(38, 2),
(38, 4),
(39, 1),
(39, 2),
(39, 4),
(40, 1),
(40, 2),
(40, 4),
(41, 1),
(41, 2),
(41, 4),
(42, 1),
(42, 2),
(42, 4),
(43, 1),
(43, 2),
(43, 4),
(44, 1),
(44, 2),
(44, 4),
(45, 1),
(46, 1),
(46, 2),
(46, 4),
(47, 1),
(47, 3),
(47, 5),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(60, 2),
(61, 1),
(61, 3),
(62, 1),
(62, 3),
(63, 1),
(63, 3),
(64, 1),
(64, 3),
(65, 1),
(65, 3),
(66, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `course_id`, `position`, `title`, `created_at`, `updated_at`) VALUES
(22, 11, 0, 'محتوى الكورس', '2026-03-17 18:39:02', '2026-03-17 18:39:02');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('Jn275NZCq7S8ouyOPa7QfhkgbzkLli8rndiwK4IV', NULL, '184.154.139.42', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/6.0)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVVpaR1RvVjFhY2xzeVBzbkd1MFNSMkFtVDdUY0NRdFRKMUh4dXJSUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHA6Ly9mYWhtZWFuLnVzdGF6eS5jb20vY291cnNlcy9jb3Vyc2Utd2l0aC10YWIiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1776058666),
('2nmGc6HP4xbvoXWSXQmlC6XUIl6gDKdoLQ8OjONq', NULL, '159.223.31.240', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYURGNmVDOWg3TVNaUlVpeDlJMHVaQlVSR1VHV2dpT3BpOUlmZ1pRbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZmFobWVhbi51c3RhenkuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1776012651),
('v3Og91cP8VaX49GUI5issKFkYcntTF6vObJIKaL6', NULL, '184.154.139.42', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/6.0)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibjZ3dEx4R2luSVJGTUowOTB1VlZlajJnZHZOTkhVSUpqU3pJU1hUNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjU6Imh0dHA6Ly9mYWhtZWFuLnVzdGF6eS5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1776058661),
('sRNz2EupWy7rlB1ezThYroWXydMXA9IMjM2Xm2dm', NULL, '197.52.90.65', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2RwRWhyYmFFNUk5RnN1c2ZxanE1STdFUzdXaFJjckpybEFadGh4ZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZmFobWVhbi51c3RhenkuY29tIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1776006137);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `education_level_id` bigint(20) UNSIGNED DEFAULT NULL,
  `grade_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `student_phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `student_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `education_level_id`, `grade_id`, `status`, `student_phone_number`, `parent_phone_number`, `academic_year`, `teacher_id`, `student_code`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 1, 'pending', '01145195373', NULL, NULL, NULL, NULL, '2026-01-12 10:47:53', '2026-01-13 10:06:28'),
(2, 9, 1, 1, 'pending', NULL, NULL, NULL, NULL, NULL, '2026-01-13 09:50:59', '2026-01-14 14:00:23'),
(3, 10, 1, 2, 'approved', '01145195373', NULL, NULL, NULL, NULL, '2026-01-15 10:12:03', '2026-01-15 10:12:03'),
(4, 13, 1, 1, 'approved', '01117661324', NULL, NULL, NULL, NULL, '2026-03-01 19:51:27', '2026-03-01 19:51:27'),
(5, 14, 1, 1, 'approved', '01145195373', NULL, NULL, NULL, NULL, '2026-03-16 19:23:56', '2026-03-16 19:23:56'),
(6, 16, 1, 1, 'pending', '01145195373', '01145195373', '2024-2025', NULL, 'ST-00016', '2026-04-12 20:29:40', '2026-04-12 20:29:40');

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `grade_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `grade_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 'لغة عربية', '2025-12-16 07:29:55', '2025-12-16 07:29:55'),
(2, 1, 'لغة انجليزية', '2026-01-12 05:54:55', '2026-01-12 05:54:55'),
(3, 1, 'التاريخ', '2026-01-19 21:26:53', '2026-01-19 21:26:53'),
(4, 2, 'التاريخ', '2026-01-19 21:27:07', '2026-01-19 21:27:07'),
(5, 3, 'التاريخ', '2026-01-19 21:27:20', '2026-01-19 21:27:20');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_education_level`
--

CREATE TABLE `teacher_education_level` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `education_level_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teacher_education_level`
--

INSERT INTO `teacher_education_level` (`id`, `teacher_id`, `education_level_id`, `created_at`, `updated_at`) VALUES
(1, 4, 1, NULL, NULL),
(2, 12, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_grade`
--

CREATE TABLE `teacher_grade` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `grade_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teacher_grade`
--

INSERT INTO `teacher_grade` (`id`, `teacher_id`, `grade_id`, `created_at`, `updated_at`) VALUES
(1, 4, 1, NULL, NULL),
(2, 4, 2, NULL, NULL),
(3, 12, 1, NULL, NULL),
(4, 12, 2, NULL, NULL),
(5, 12, 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subject`
--

CREATE TABLE `teacher_subject` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teacher_subject`
--

INSERT INTO `teacher_subject` (`id`, `user_id`, `subject_id`, `created_at`, `updated_at`) VALUES
(1, 4, 1, NULL, NULL),
(2, 6, 2, NULL, NULL),
(3, 7, 1, NULL, NULL),
(4, 11, 3, NULL, NULL),
(5, 12, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone_number`, `email_verified_at`, `password`, `profile_image`, `remember_token`, `created_at`, `updated_at`, `teacher_id`) VALUES
(4, 'سامح احمد', 'sameh@example.com', NULL, NULL, '$2y$12$L1AdyupPS.mmP45kN4.XQuOQ6P0baKTnFB7N2yQkBVTwBIJr71rAy', 'profiles/oFs0ZdNQwDJpB6EtfMjnGmyUvWkUtvs7PRweFkgZ.png', NULL, '2025-12-16 09:07:18', '2026-01-21 18:57:12', NULL),
(5, 'Admin User', 'admin@example.com', NULL, NULL, '$2y$12$XGGZKwaXMGOKdZL2rNufW.obP1a9v/GCAJieduKug/pf6ViIK2wYa', 'profiles/Mspj9Y6Cq5Xzp9nniZTOnRpjD2LkLiaLPXYefwnp.png', 'DNBWAQwhe7Bif3bOV96vXFWrpfjC0hTSNKwQSvUbIefbjJHewAa9g8pAxnUx', '2026-01-10 15:45:14', '2026-01-21 16:20:25', NULL),
(12, 'سعيد عبد الغفور البورعي', 'bora3y@fahmean.com', NULL, NULL, '$2y$12$5PUtDy4q3dzUJdarvD5pzeohHbNacWxd9IpUnlecw..gzUMKhC0Ny', 'profiles/RP6usb4F8yKBUKzPKqcnTQOnXPaTnqfzVXCJZ1od.png', NULL, '2026-02-09 03:21:43', '2026-02-14 16:41:11', NULL),
(13, 'Rawan Sameh Ahmed', 'rawan@fahmean.com', NULL, NULL, '$2y$12$.HT/FCTyrjsdRQx7PY1od.r3wjVeOpo0wcjZl7ByShCdX4Hw8Emhm', 'profiles/LsM125HwoxgkBAJa7JNsfBsdGA7eV9KTbfk8i4U7.jpg', NULL, '2026-03-01 19:51:27', '2026-03-01 19:56:11', NULL),
(14, 'احمد محمد احمد', 'ahmed@gmail.com', '01145195373', NULL, '$2y$12$rC9cLowu2a/351Hs7zV0ku1U/9pvIgofr.hH0zG0i4ZhhI0M1RSBa', NULL, NULL, '2026-03-16 19:23:56', '2026-03-16 19:23:56', NULL),
(15, 'عماد رشاد عبدالحيم', 'emad@gmail.com', '01145195373', NULL, '$2y$12$467jDJgaA.rhCfiUOU/AfOOFWlEMmHDktknlHon2Q3NPsEBqnGilu', NULL, NULL, '2026-04-12 20:21:46', '2026-04-12 20:21:46', NULL),
(16, 'عماد رشاد عبدالحليم', 'emad@gm.com', '01145195373', NULL, '$2y$12$AGIsrZQx/DjQbxY5eW.C7.hh/srYy938WRfc/iAPG2xgzZ1t4T5Ee', NULL, NULL, '2026-04-12 20:29:39', '2026-04-12 20:29:39', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `answers_question_id_foreign` (`question_id`);

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignments_section_id_foreign` (`section_id`);

--
-- Indexes for table `assignment_submissions`
--
ALTER TABLE `assignment_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assignment_submissions_assignment_id_foreign` (`assignment_id`),
  ADD KEY `assignment_submissions_student_id_foreign` (`student_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupons_code_unique` (`code`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `courses_teacher_id_foreign` (`teacher_id`),
  ADD KEY `courses_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `course_student`
--
ALTER TABLE `course_student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_student_course_id_foreign` (`course_id`),
  ADD KEY `course_student_student_id_foreign` (`student_id`);

--
-- Indexes for table `education_levels`
--
ALTER TABLE `education_levels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `grades_education_level_id_foreign` (`education_level_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lessons`
--
ALTER TABLE `lessons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lessons_section_id_foreign` (`section_id`);

--
-- Indexes for table `lesson_files`
--
ALTER TABLE `lesson_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lesson_files_lesson_id_foreign` (`lesson_id`);

--
-- Indexes for table `lesson_student`
--
ALTER TABLE `lesson_student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lesson_student_lesson_id_foreign` (`lesson_id`),
  ADD KEY `lesson_student_student_id_foreign` (`student_id`);

--
-- Indexes for table `login_activities`
--
ALTER TABLE `login_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_activities_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`),
  ADD KEY `orders_coupon_id_foreign` (`coupon_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_course_id_foreign` (`course_id`);

--
-- Indexes for table `parent_student`
--
ALTER TABLE `parent_student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_student_parent_id_foreign` (`parent_id`),
  ADD KEY `parent_student_student_id_foreign` (`student_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questions_quiz_id_foreign` (`quiz_id`);

--
-- Indexes for table `quizzes`
--
ALTER TABLE `quizzes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quizzes_section_id_foreign` (`section_id`),
  ADD KEY `quizzes_lesson_id_foreign` (`lesson_id`),
  ADD KEY `quizzes_teacher_id_foreign` (`teacher_id`);

--
-- Indexes for table `quiz_student`
--
ALTER TABLE `quiz_student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_student_quiz_id_foreign` (`quiz_id`),
  ADD KEY `quiz_student_student_id_foreign` (`student_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sections_course_id_foreign` (`course_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `students_user_id_foreign` (`user_id`),
  ADD KEY `students_education_level_id_foreign` (`education_level_id`),
  ADD KEY `students_grade_id_foreign` (`grade_id`),
  ADD KEY `students_teacher_id_foreign` (`teacher_id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_subject_student_id_foreign` (`student_id`),
  ADD KEY `student_subject_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subjects_grade_id_foreign` (`grade_id`);

--
-- Indexes for table `teacher_education_level`
--
ALTER TABLE `teacher_education_level`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_education_level_teacher_id_foreign` (`teacher_id`),
  ADD KEY `teacher_education_level_education_level_id_foreign` (`education_level_id`);

--
-- Indexes for table `teacher_grade`
--
ALTER TABLE `teacher_grade`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_grade_teacher_id_foreign` (`teacher_id`),
  ADD KEY `teacher_grade_grade_id_foreign` (`grade_id`);

--
-- Indexes for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_subject_user_id_foreign` (`user_id`),
  ADD KEY `teacher_subject_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_teacher_id_foreign` (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assignment_submissions`
--
ALTER TABLE `assignment_submissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `course_student`
--
ALTER TABLE `course_student`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `education_levels`
--
ALTER TABLE `education_levels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lessons`
--
ALTER TABLE `lessons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `lesson_files`
--
ALTER TABLE `lesson_files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lesson_student`
--
ALTER TABLE `lesson_student`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_activities`
--
ALTER TABLE `login_activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `parent_student`
--
ALTER TABLE `parent_student`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `quizzes`
--
ALTER TABLE `quizzes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `quiz_student`
--
ALTER TABLE `quiz_student`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `student_subject`
--
ALTER TABLE `student_subject`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `teacher_education_level`
--
ALTER TABLE `teacher_education_level`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `teacher_grade`
--
ALTER TABLE `teacher_grade`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
